﻿// CST-150 Activity 4 - File Processing with Methods
// Name: Eric Gathinji
// Date: June 29, 2025
// This code reads a structured text file, formats content for display,
// allows the user to select and increment a quantity, and saves the updated content.

using System;
using System.IO;
using System.Windows.Forms;

namespace CST_150_Activity_3
{
    public partial class FrmMain : Form
    {
        // Class-level variables
        private string[] lines;
        private string txtFilePath;

        public FrmMain()
        {
            InitializeComponent();
            lblResults.Visible = false;
            lblSelectedFile.Visible = false;
            lblSelectRow.Visible = false;
            cmbSelectRow.Visible = false;
        }

        /// <summary>
        /// Event handler for the "Read File" button click.
        /// Reads Topic3.txt from Data folder and displays results.
        /// </summary>
        private void BtnReadFileClickEvent(object sender, EventArgs e)
        {
            try
            {
                txtFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", "Topic3.txt");

                if (!File.Exists(txtFilePath))
                {
                    MessageBox.Show("The file Topic3.txt was not found.");
                    return;
                }

                lines = File.ReadAllLines(txtFilePath);

                // Convert content to lowercase and display
                string fileContent = string.Join(Environment.NewLine, lines);
                ConvertLowerCase(fileContent);

                // Populate comboBox with row numbers
                cmbSelectRow.Items.Clear();
                for (int i = 1; i <= lines.Length; i++)
                {
                    cmbSelectRow.Items.Add($"Row {i}");
                }

                lblSelectRow.Visible = true;
                cmbSelectRow.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while reading the file:\n" + ex.Message);
            }
        }

        /// <summary>
        /// Converts all file content to lowercase and sends to label.
        /// </summary>
        private void ConvertLowerCase(string fileContent)
        {
            string lowerCaseText = fileContent.ToLower();
            ResultsToLabel(lowerCaseText);
        }

        /// <summary>
        /// Displays string content in the results label.
        /// </summary>
        private void ResultsToLabel(string content)
        {
            lblResults.Text = content;
            lblResults.Visible = true;
        }

        /// <summary>
        /// Displays updated file content with formatting.
        /// </summary>
        private void DisplayInventory()
        {
            string results = "Item Name         Quantity\tPrice\n";
            results += "------------------------------------------\n";

            foreach (string line in lines)
            {
                string[] parts = line.Split(',');
                if (parts.Length == 3)
                {
                    string name = parts[0];
                    int quantity = int.Parse(parts[1]);
                    decimal price = decimal.Parse(parts[2]);

                    results += string.Format("{0,-16}\t{1,5}\t${2,7:F2}\n", name, quantity, price);
                }
            }

            lblResults.Text = results;
            lblResults.Visible = true;
        }

        /// <summary>
        /// Increments the quantity of the selected row by 1.
        /// </summary>
        private void GetQty(int rowIndex)
        {
            try
            {
                string[] splitLine = lines[rowIndex].Split(',');
                int quantity = int.Parse(splitLine[1]);
                quantity++;
                splitLine[1] = quantity.ToString();
                lines[rowIndex] = string.Join(",", splitLine);
            }
            catch (FormatException)
            {
                MessageBox.Show("Quantity could not be parsed to an integer.");
            }
        }

        /// <summary>
        /// Writes updated data back to the text file.
        /// </summary>
        private void IncDisplayQty()
        {
            File.WriteAllLines(txtFilePath, lines);
        }

        /// <summary>
        /// Handles comboBox selection to increment quantity.
        /// </summary>
        private void SelectRowToInc(object sender, EventArgs e)
        {
            int rowSelected = cmbSelectRow.SelectedIndex;
            if (rowSelected >= 0)
            {
                GetQty(rowSelected);
                IncDisplayQty();
                DisplayInventory(); // Refresh display
            }
            else
            {
                MessageBox.Show("Please select a valid row.");
            }
        }
    }
}
