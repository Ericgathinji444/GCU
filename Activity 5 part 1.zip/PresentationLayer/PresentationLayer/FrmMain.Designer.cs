﻿// CST-150 Activity 5 – Part 1 Designer Code
// Author: Eric Gathinji
// Grand Canyon University – July 2025

using System.Drawing;
using System.Windows.Forms;

namespace PresentationLayer
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtName = new TextBox();
            this.btnAddDog = new Button();
            this.txtNeck = new TextBox();
            this.cmbSit = new ComboBox();
            this.txtColor = new TextBox();
            this.txtWeight = new TextBox();
            this.lblName = new Label();
            this.lblRadius = new Label();
            this.label2 = new Label();
            this.lblSit = new Label();
            this.lblColor = new Label();
            this.lblWeight = new Label();
            this.label1 = new Label();
            this.grpAttributes = new GroupBox();
            this.gvShowDogs = new DataGridView();
            this.lblErrorMessage = new Label();

            this.grpAttributes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)this.gvShowDogs).BeginInit();
            this.SuspendLayout();

            // grpAttributes
            this.grpAttributes.Controls.Add(this.txtName);
            this.grpAttributes.Controls.Add(this.txtNeck);
            this.grpAttributes.Controls.Add(this.cmbSit);
            this.grpAttributes.Controls.Add(this.txtColor);
            this.grpAttributes.Controls.Add(this.txtWeight);
            this.grpAttributes.Controls.Add(this.lblName);
            this.grpAttributes.Controls.Add(this.lblRadius);
            this.grpAttributes.Controls.Add(this.label2);
            this.grpAttributes.Controls.Add(this.lblSit);
            this.grpAttributes.Controls.Add(this.lblColor);
            this.grpAttributes.Controls.Add(this.lblWeight);
            this.grpAttributes.Controls.Add(this.label1);
            this.grpAttributes.Location = new Point(30, 30);
            this.grpAttributes.Name = "grpAttributes";
            this.grpAttributes.Size = new Size(400, 300);
            this.grpAttributes.Text = "Dog Attributes";

            // Labels & Inputs
            this.lblName.Location = new Point(20, 30);
            this.lblName.Text = "Dog Name:";
            this.txtName.Location = new Point(150, 25);
            this.txtName.Size = new Size(200, 25);

            this.lblRadius.Location = new Point(20, 65);
            this.lblRadius.Text = "Neck Radius:";
            this.txtNeck.Location = new Point(150, 60);
            this.txtNeck.Size = new Size(120, 25);
            this.label2.Text = "inches";
            this.label2.Location = new Point(280, 65);

            this.lblSit.Location = new Point(20, 100);
            this.lblSit.Text = "Sitting:";
            this.cmbSit.Location = new Point(150, 95);
            this.cmbSit.Size = new Size(120, 25);
            this.cmbSit.Items.AddRange(new object[] { "Yes", "No" });

            this.lblColor.Location = new Point(20, 135);
            this.lblColor.Text = "Color:";
            this.txtColor.Location = new Point(150, 130);
            this.txtColor.Size = new Size(120, 25);

            this.lblWeight.Location = new Point(20, 170);
            this.lblWeight.Text = "Weight:";
            this.txtWeight.Location = new Point(150, 165);
            this.txtWeight.Size = new Size(120, 25);
            this.label1.Text = "pounds";
            this.label1.Location = new Point(280, 170);

            // btnAddDog
            this.btnAddDog.Location = new Point(450, 60);
            this.btnAddDog.Size = new Size(120, 40);
            this.btnAddDog.Text = "Add New Dog";
            this.btnAddDog.Click += new System.EventHandler(this.btnAddDog_Click);

            // gvShowDogs
            this.gvShowDogs.Location = new Point(30, 350);
            this.gvShowDogs.Size = new Size(600, 200);
            this.gvShowDogs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            // lblErrorMessage
            this.lblErrorMessage.Location = new Point(30, 560);
            this.lblErrorMessage.Size = new Size(400, 25);
            this.lblErrorMessage.ForeColor = Color.Red;
            this.lblErrorMessage.Visible = false;

            // FrmMain
            this.AutoScaleDimensions = new SizeF(8F, 16F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(700, 600);
            this.Text = "Dog Manager";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Controls.Add(this.grpAttributes);
            this.Controls.Add(this.btnAddDog);
            this.Controls.Add(this.gvShowDogs);
            this.Controls.Add(this.lblErrorMessage);

            this.grpAttributes.ResumeLayout(false);
            this.grpAttributes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)this.gvShowDogs).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private TextBox txtName;
        private Button btnAddDog;
        private TextBox txtNeck;
        private ComboBox cmbSit;
        private TextBox txtColor;
        private TextBox txtWeight;
        private Label lblName;
        private Label lblRadius;
        private Label label2;
        private Label lblSit;
        private Label lblColor;
        private Label lblWeight;
        private Label label1;
        private GroupBox grpAttributes;
        private DataGridView gvShowDogs;
        private Label lblErrorMessage;
    }
}