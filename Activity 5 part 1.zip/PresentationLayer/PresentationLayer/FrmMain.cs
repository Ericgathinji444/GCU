// CST-150 Activity 5 � Part 1
// Author: Eric Gathinji
// Grand Canyon University � July 2025
// Description: FrmMain.cs represents the presentation layer where users input dog attributes. This class handles UI interaction and delegates logic to the business layer.

using System;
using System.Windows.Forms;
using BusinessLayer; // Reference to the Dog class in the business logic layer

namespace PresentationLayer
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
            this.Load += FrmMain_Load; // Ensure FrmMain_Load is wired up on form load
        }

        /// <summary>
        /// Initialize the DataGridView columns on form load.
        /// </summary>
        private void FrmMain_Load(object sender, EventArgs e)
        {
            gvShowDogs.AutoGenerateColumns = false; // Disable automatic column generation
            gvShowDogs.Columns.Clear();

            gvShowDogs.Columns.Add("Name", "Name");
            gvShowDogs.Columns.Add("NeckCir", "Neck Cir (cm)");
            gvShowDogs.Columns.Add("SitOrLay", "Sit or Lay");
            gvShowDogs.Columns.Add("WeightKg", "Weight (kg)");
            gvShowDogs.Columns.Add("Color", "Color");

            cmbSit.SelectedIndex = -1; // Ensure default combo state
        }

        /// <summary>
        /// Handles the Add Dog button click event.
        /// Validates inputs, creates Dog object, and displays in DataGridView.
        /// </summary>
        private void btnAddDog_Click(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;

            string name = txtName.Text.Trim();
            string color = txtColor.Text.Trim();
            string sitOrLay = cmbSit.Text.Trim();

            bool validNeck = double.TryParse(txtNeck.Text, out double neckRadius);
            bool validWeight = double.TryParse(txtWeight.Text, out double weight);

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(color) ||
                string.IsNullOrWhiteSpace(sitOrLay) || !validNeck || !validWeight)
            {
                lblErrorMessage.Text = "Please fill the incorrect data entry....... Then try again";
                lblErrorMessage.Visible = true;
                return;
            }

            // Create Dog object using parameterized constructor
            Dog newDog = new Dog(name, neckRadius, sitOrLay, color, weight);

            // Display data in DataGridView
            gvShowDogs.Rows.Add(
                newDog.Name,
                newDog.CalCircumference().ToString("F2"), 
                newDog.SitOrLay,
                newDog.CalWeight().ToString("F2"),
                newDog.Color
            );

            // Clear input fields for next entry
            txtName.Clear();
            txtNeck.Clear();
            txtWeight.Clear();
            txtColor.Clear();
            cmbSit.SelectedIndex = -1;
        }
    }
}