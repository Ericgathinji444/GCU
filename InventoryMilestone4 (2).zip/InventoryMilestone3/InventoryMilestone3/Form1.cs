﻿// CST-150 Milestone 4 - Refactored Inventory Application
// Author: Eric Gathinji
// 05: July 2025
// Description: This application reads, displays, updates, and manages inventory data using clean method-based structure.

using System;
using System.Data.SqlTypes;
using System.IO;
using System.Windows.Forms;

namespace InventoryMilestone4
{
    public partial class Form1 : Form
    {
        InventoryItem[] inventory;
        string filePath = Path.Combine(Application.StartupPath, "Data", "Inventory.txt");


        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the button click to show inventory.
        /// </summary>
        private void btnShowInventory_Click(object sender, EventArgs e)
        {
            ReadInventory();             // Step 1: Read file and populate inventory array
            IncrementFirstItem();        // Step 4: Business logic to increment first item
            UpdateInventoryFile();       // Step 4: Persist changes
            DisplayInventory();          // Step 2: Display to UI
        }

        /// <summary>
        /// Reads the inventory from the text file and populates the inventory array.
        /// </summary>
        private void ReadInventory()
        {
            try
            {
                string[] lines = File.ReadAllLines(filePath);
                inventory = new InventoryItem[lines.Length];

                for (int i = 0; i < lines.Length; i++)
                {
                    string[] parts = lines[i].Split(',');

                    inventory[i] = new InventoryItem
                    {
                        Description = parts[0],
                        Quantity = int.Parse(parts[1]),
                        Cost = decimal.Parse(parts[2]),
                        Supplier = parts[3],
                        DateAdded = DateTime.Parse(parts[4])
                    };
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading inventory: {ex.Message}", "File Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Displays the inventory on the label control.
        /// </summary>
        private void DisplayInventory()
        {
            string output = "Current Inventory:\n\n";
            foreach (var item in inventory)
            {
                output += $"Item: {item.Description}\n" +
                          $"Qty: {item.Quantity}\n" +
                          $"Cost: ${item.Cost}\n" +
                          $"Supplier: {item.Supplier}\n" +
                          $"Date: {item.DateAdded.ToShortDateString()}\n\n";
            }
            lblInventory.Text = output;
        }

        /// <summary>
        /// Increments the quantity of the first inventory item.
        /// </summary>
        private void IncrementFirstItem()
        {
            if (inventory != null && inventory.Length > 0)
            {
                inventory[0].Quantity += 10;
            }
        }

        /// <summary>
        /// Writes the updated inventory back to the text file.
        /// </summary>
        private void UpdateInventoryFile()
        {
            try
            {
                string[] lines = new string[inventory.Length];
                for (int i = 0; i < inventory.Length; i++)
                {
                    var item = inventory[i];
                    lines[i] = $"{item.Description},{item.Quantity},{item.Cost},{item.Supplier},{item.DateAdded:yyyy-MM-dd}";
                }
                File.WriteAllLines(filePath, lines);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error writing inventory: {ex.Message}", "Write Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    /// <summary>
    /// Inventory item model for Milestone 4.
    /// </summary>
    public class InventoryItem
    {
        public string Description { get; set; }
        public int Quantity { get; set; }
        public decimal Cost { get; set; }
        public string Supplier { get; set; }
        public DateTime DateAdded { get; set; }
    }
}
