﻿namespace InventoryMilestone4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnShowInventory = new System.Windows.Forms.Button();
            this.lblInventory = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnShowInventory
            // 
            this.btnShowInventory.Location = new System.Drawing.Point(30, 30);
            this.btnShowInventory.Name = "btnShowInventory";
            this.btnShowInventory.Size = new System.Drawing.Size(150, 40);
            this.btnShowInventory.TabIndex = 0;
            this.btnShowInventory.Text = "Show Inventory";
            this.btnShowInventory.UseVisualStyleBackColor = true;
            this.btnShowInventory.Click += new System.EventHandler(this.btnShowInventory_Click);
            // 
            // lblInventory
            // 
            this.lblInventory.AutoSize = true;
            this.lblInventory.Font = new System.Drawing.Font("Consolas", 10F);
            this.lblInventory.Location = new System.Drawing.Point(30, 90);
            this.lblInventory.Name = "lblInventory";
            this.lblInventory.Size = new System.Drawing.Size(0, 20);
            this.lblInventory.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 500);
            this.Controls.Add(this.lblInventory);
            this.Controls.Add(this.btnShowInventory);
            this.Name = "Form1";
            this.Text = "Inventory Milestone 4";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnShowInventory;
        private System.Windows.Forms.Label lblInventory;
    }
}
