﻿// CST-150 Activity 4 - Part 2: Method Demonstration
// Author: Eric Gathinji
// Date: July 2025
// Description: This Windows Forms app demonstrates the use of methods with parameters, return values, and control structures.

using System;
using System.Windows.Forms;

namespace CST150_Methods
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Event handler for the Execute Methods button.
        /// Invokes all 9 methods to demonstrate parameter and return value usage.
        /// </summary>
        private void BtnExecuteMethods_Click(object sender, EventArgs e)
        {
            SumInts(5, 10);
            double avg = AverageOfFive(3.5, 4.0, 5.2, 6.0, 7.3);
            Display($"Average: {avg}");

            int randSum = RandomSum();
            Display($"Random Sum: {randSum}");

            bool divisible = IsSumDivisibleBy2(3, 5, 2);
            Display($"Sum divisible by 2: {divisible}");

            ShorterString("hello", "world!");
            double largest = FindLargestValue(new double[] { 2.5, 4.9, 1.2, 9.0 });
            Display($"Largest value: {largest}");

            int[] nums = GenerateIntArray();
            Display($"Generated Array: {string.Join(", ", nums)}");

            bool match = CompareBools(true, true);
            Display($"Booleans Match: {match}");

            double product = MultiplyIntDouble(4, 2.5);
            Display($"Product: {product}");
        }

        /// <summary>
        /// Adds two integers and displays the sum.
        /// </summary>
        private void SumInts(int a, int b)
        {
            int sum = a + b;
            Display($"Sum of {a} and {b} is {sum}");
        }

        /// <summary>
        /// Calculates the average of five double values.
        /// </summary>
        private double AverageOfFive(double a, double b, double c, double d, double e)
        {
            return (a + b + c + d + e) / 5;
        }

        /// <summary>
        /// Returns the sum of two randomly generated integers.
        /// </summary>
        private int RandomSum()
        {
            Random rnd = new Random();
            int x = rnd.Next(1, 100);
            int y = rnd.Next(1, 100);
            return x + y;
        }

        /// <summary>
        /// Returns true if the sum of three integers is divisible by 2.
        /// </summary>
        private bool IsSumDivisibleBy2(int a, int b, int c)
        {
            return ((a + b + c) % 2 == 0);
        }

        /// <summary>
        /// Displays the shorter of two strings.
        /// </summary>
        private void ShorterString(string str1, string str2)
        {
            string shorter = str1.Length < str2.Length ? str1 : str2;
            Display($"Shorter string: {shorter}");
        }

        /// <summary>
        /// Returns the largest value in a double array.
        /// </summary>
        private double FindLargestValue(double[] array)
        {
            double max = array[0];
            foreach (double val in array)
            {
                if (val > max) max = val;
            }
            return max;
        }

        /// <summary>
        /// Generates an array of 10 random integers.
        /// </summary>
        private int[] GenerateIntArray()
        {
            int[] values = new int[10];
            Random rnd = new Random();
            for (int i = 0; i < 10; i++)
            {
                values[i] = rnd.Next(0, 100);
            }
            return values;
        }

        /// <summary>
        /// Compares two boolean values and returns true if they match.
        /// </summary>
        private bool CompareBools(bool a, bool b)
        {
            return a == b;
        }

        /// <summary>
        /// Multiplies an integer and a double and returns the product.
        /// </summary>
        private double MultiplyIntDouble(int num, double val)
        {
            return num * val;
        }

        /// <summary>
        /// Appends a line of text to the lblResults label.
        /// </summary>
        private void Display(string text)
        {
            lblResults.Text += text + Environment.NewLine;
        }
    }
}
