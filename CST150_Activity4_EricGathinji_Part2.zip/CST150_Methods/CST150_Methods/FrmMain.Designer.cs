﻿namespace CST150_Methods
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Method required for Designer support.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExecuteMethods = new System.Windows.Forms.Button();
            this.lblResults = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnExecuteMethods
            // 
            this.btnExecuteMethods.Location = new System.Drawing.Point(50, 30);
            this.btnExecuteMethods.Name = "btnExecuteMethods";
            this.btnExecuteMethods.Size = new System.Drawing.Size(150, 40);
            this.btnExecuteMethods.TabIndex = 0;
            this.btnExecuteMethods.Text = "Execute Methods";
            this.btnExecuteMethods.UseVisualStyleBackColor = true;
            this.btnExecuteMethods.Click += new System.EventHandler(this.BtnExecuteMethods_Click);
            // 
            // lblResults
            // 
            this.lblResults.AutoSize = true;
            this.lblResults.Font = new System.Drawing.Font("Consolas", 10F);
            this.lblResults.Location = new System.Drawing.Point(50, 90);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(0, 20);
            this.lblResults.TabIndex = 1;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResults);
            this.Controls.Add(this.btnExecuteMethods);
            this.Name = "FrmMain";
            this.Text = "Main Form - Method Demo";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnExecuteMethods;
        private System.Windows.Forms.Label lblResults;
    }
}
