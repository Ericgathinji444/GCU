﻿/*
 * Name: Eric Gathinji
 * CST-150
 * Activity 2
 * 23/06/2025
 * Citation(s) 
Krill, P. (2023, February 17). Microsoft offers Visual Studio IDE extension for .NET upgrades. InfoWorld.Com.
Yan, N. (2024). Computer Software Programming based on C Language. 2024 Asian Conference on Intelligent Technologies (ACOIT), Intelligent Technologies (ACOIT), 2024 Asian Conference On, 1–5. https://doi.org/10.1109/ACOIT62457.2024.10941661
Tan, J., Chen, Y., & Jiao, S. (2023). Visual Studio Code in Introductory Computer Science Course: An Experience Report.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CST_150_Activity_1
{
    public partial class Form1 : Form
    {
        // Constants for time conversions
        private const int SECONDS_IN_MINUTE = 60;
        private const int SECONDS_IN_HOUR = 3600;
        private const int SECONDS_IN_DAY = 86400;

        public Form1()
        {
            InitializeComponent();
            // Hide all output labels
            lblResult.Visible = false;
        }

        /// <summary>
        /// Handles the click event for the Convert button.
        /// </summary>
        private void ConvertButtonClickEvent(object sender, EventArgs e)
        {
            int seconds;
            lblResult.Visible = false;

            if (int.TryParse(txtSeconds.Text, out seconds) && seconds >= 0)
            {
                string output = "";

                if (seconds >= SECONDS_IN_MINUTE)
                {
                    int minutes = seconds / SECONDS_IN_MINUTE;
                    output += $"Minutes: {minutes}\n";

                    if (seconds >= SECONDS_IN_HOUR)
                    {
                        int hours = seconds / SECONDS_IN_HOUR;
                        output += $"Hours: {hours}\n";

                        if (seconds >= SECONDS_IN_DAY)
                        {
                            int days = seconds / SECONDS_IN_DAY;
                            output += $"Days: {days}";
                        }
                    }
                }
                else
                {
                    output = "Seconds must be at least 60 to convert to minutes.";
                }

                lblResult.Text = output;
                lblResult.Visible = true;
            }
            else
            {
                MessageBox.Show("Please enter a valid non-negative number of seconds.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
    }
}
