﻿using System;
using System.IO;
using System.Windows.Forms;

namespace InventoryMilestone3
{
    public partial class Form1 : Form
    {
        // Array to store inventory items
        InventoryItem[] inventory;

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the click event for Show Inventory button.
        /// </summary>
        private void btnShowInventory_Click(object sender, EventArgs e)
        {
            try
            {
                // Path to your text file (relative to bin\Debug\net7.0-windows\Data)
                string filePath = @"Data\Inventory.txt";

                // Read all lines
                string[] lines = File.ReadAllLines(filePath);

                // Initialize array
                inventory = new InventoryItem[lines.Length];

                // Loop & parse each line
                for (int i = 0; i < lines.Length; i++)
                {
                    string[] parts = lines[i].Split(',');

                    // Use primitive variables to parse parts
                    string description = parts[0];
                    int quantity = int.Parse(parts[1]);
                    decimal cost = decimal.Parse(parts[2]);
                    string supplier = parts[3];
                    DateTime dateAdded = DateTime.Parse(parts[4]);

                    inventory[i] = new InventoryItem
                    {
                        Description = description,
                        Quantity = quantity,
                        Cost = cost,
                        Supplier = supplier,
                        DateAdded = dateAdded
                    };
                }

                // Increment quantity for first item
                if (inventory.Length > 0)
                {
                    inventory[0].Quantity += 10;
                }

                // Build output string
                string output = "Current Inventory:\n\n";
                foreach (var item in inventory)
                {
                    output += $"Item: {item.Description}\n" +
                              $"Qty: {item.Quantity}\n" +
                              $"Cost: ${item.Cost}\n" +
                              $"Supplier: {item.Supplier}\n" +
                              $"Date: {item.DateAdded.ToShortDateString()}\n\n";
                }

                //  Display in label
                lblInventory.Text = output;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
    }

    /// <summary>
    /// Inventory item model for Milestone 3.
    /// </summary>
    public class InventoryItem
    {
        public string Description { get; set; }
        public int Quantity { get; set; }
        public decimal Cost { get; set; }
        public string Supplier { get; set; }
        public DateTime DateAdded { get; set; }
    }
}
