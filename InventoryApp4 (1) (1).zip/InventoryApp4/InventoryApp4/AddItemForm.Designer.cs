﻿using System;
using System.Windows.Forms;

namespace InventoryApp4
{
    public partial class AddItemForm : Form
    {
        

        // Event handler for the "Save Item" button click.
        private void btnSaveItem_Click(object sender, EventArgs e)
        {
            // UI Controls Setup:
            // In the Visual Studio Designer for AddItemForm:
            // 1. Drag 'Label' controls for "Description:", "Quantity:", "Cost:", "Category:".
            // 2. Drag 'TextBox' controls next to each label:
            //    - Name: txtDescription
            //    - Name: txtQuantity (Set 'Text' to '0' initially, 'MaxLength' if desired)
            //    - Name: txtCost (Set 'Text' to '0.00' initially)
            //    - Name: txtCategory
            // 3. Drag two 'Button' controls:
            //    - Name: btnSaveItem, Text: Save Item
            //    - Name: btnCancel, Text: Cancel

            // Input validation
            if (string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                MessageBox.Show("Description cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!int.TryParse(txtQuantity.Text, out int quantity) || quantity < 0)
            {
                MessageBox.Show("Please enter a valid non-negative quantity.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!decimal.TryParse(txtCost.Text, out decimal cost) || cost < 0)
            {
                MessageBox.Show("Please enter a valid non-negative cost.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtCategory.Text))
            {
                MessageBox.Show("Category cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Generate a new unique ID.
            string newId = Program.GenerateItemId();
            DateTime dateAdded = DateTime.Now;

            // Create a new InventoryItem object.
            InventoryItem newItem = new InventoryItem(newId, txtDescription.Text.Trim(), quantity, cost, txtCategory.Text.Trim(), dateAdded);

            // Add the new item to the shared inventory list.
            Program.Inventory.Add(newItem);

            MessageBox.Show($"Item '{newItem.ItemDescription}' (ID: {newItem.ItemId}) added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.Close(); // Close the form after saving.
        }

        // Event handler for the "Cancel" button click.
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the form without saving changes.
        }

        private Label label1;
        private TextBox txtDescription;
        private Label label2;
        private TextBox txtQuantity;
        private Label label3;
        private TextBox txtCost;
        private Label label4;
        private TextBox txtCategory;
        private Button btnSaveItem;
        private Button btnCancel;
    }
}