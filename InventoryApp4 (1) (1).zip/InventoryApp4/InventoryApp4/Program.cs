﻿// Program.cs - Application Entry Point and Shared Data Management

using System; // Required for DateTime
using System.Collections.Generic; // Required for List<T>
using System.Linq; // Required for LINQ extensions like Any()
using System.Windows.Forms; // Required for Application class

// IMPORTANT: This namespace MUST EXACTLY match your project's default namespace (e.g., InventoryApp4)
namespace InventoryApp4
{
    // The 'internal static' keywords are important.
    // 'internal' means it's accessible within the current assembly (your project).
    // 'static' means you don't need to create an instance of Program to call its members.
    internal static class Program
    {
        // Static list to hold all inventory items.
        // Public and static so it can be accessed from other forms (e.g., MainForm.cs).
        public static List<InventoryItem> Inventory = new List<InventoryItem>();

        // Private static counter used to generate unique ItemIds.
        private static int _nextItemId = 1;

        /// <summary>
        /// The main entry point for the application.
        /// This method is called automatically when the application starts.
        /// [STAThread] is important for Windows Forms applications.
        /// </summary>
        [STAThread]
        static void Main() // The 'static' keyword for Main is crucial.
        {
            // Add some initial sample data to the inventory.
            AddSampleData();

            // --- IMPORTANT: Choose the correct Application Initialization based on your project's .NET version ---

            // If your project is a .NET Framework project (e.g., .NET Framework 4.7.2, 4.8):
            Application.EnableVisualStyles(); // Enables visual styles for controls.
            Application.SetCompatibleTextRenderingDefault(false); // Sets default text rendering.

            // If your project is a .NET 5, 6, 7, 8, etc. project (newer versions):
            // ApplicationConfiguration.Initialize(); // This is the modern way to initialize WinForms apps.
            // Make sure to comment out the two lines above if you use this one.

            // Runs the main form of the application.
            // 'new MainForm()' creates an instance of your MainForm.
            Application.Run(new MainForm());
        }

        /// <summary>
        /// Populates the inventory with some initial sample data.
        /// </summary>
        private static void AddSampleData()
        {
            // (Your hard-coded sample data population goes here)
            Inventory.Add(new InventoryItem(GenerateItemId(), "Laptop Pro", 10, 1200.50m, "Electronics", DateTime.Now.AddMonths(-6)));
            Inventory.Add(new InventoryItem(GenerateItemId(), "Mechanical Keyboard", 30, 75.00m, "Peripherals", DateTime.Now.AddMonths(-3)));
            // ... more items
        }

        /// <summary>
        /// Generates a unique ID for a new inventory item.
        /// </summary>
        /// <returns>A unique string identifier.</returns>
        public static string GenerateItemId()
        {
            return $"ITEM-{_nextItemId++.ToString("D4")}";
        }
    }
}
