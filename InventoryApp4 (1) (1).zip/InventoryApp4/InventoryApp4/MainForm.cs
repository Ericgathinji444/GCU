﻿// MainForm.cs - Code Behind for Form 1: Display All Items
// This file contains the logic for the main inventory display form,
// including loading data into the DataGridView and handling button clicks.


using System;
using System.Collections.Generic; // Required if you use List<T> directly (though mostly through Program.Inventory)
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq; // Required for LINQ extensions like Any() and ToList()
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using InventoryApp4;// Required for Windows Forms controls and classes

// Ensure this namespace matches your project's default namespace (e.g., InventoryApp4)
namespace InventoryApp4
{
    // The 'partial' keyword indicates that this class's definition is split across
    // multiple files (MainForm.cs and MainForm.Designer.cs).
    // The UI controls (like dataGridViewInventory, labelNoItems, buttons) are declared
    // and initialized in MainForm.Designer.cs.
    public partial class MainForm : Form
    {
        // Constructor for the MainForm.
        // It initializes the components defined in MainForm.Designer.cs.
        // There should be ONLY ONE constructor in this file.
        public MainForm()
        {
            // This call executes the auto-generated code in MainForm.Designer.cs
            // that creates and configures all your UI controls.
            InitializeComponent();

            // Set the title bar text of the form.
            this.Text = "INVENTORY MANAGEMENT SYSTEM";
        }

        // Event handler for when the MainForm loads.
        // This method is called automatically when the form is first displayed.
        // To link this method: in the Visual Studio designer, select the form,
        // go to Properties > Events (lightning bolt icon), and double-click the 'Load' event.
        private void MainForm_Load(object sender, EventArgs e)
        {
            // Populate the DataGridView with inventory data when the form loads.
            RefreshInventoryList();
        }

        /// <summary>
        /// Populates or refreshes the DataGridView with the current inventory data.
        /// This method fulfills the requirement to "display the inventory on the form."
        /// </summary>
        public void RefreshInventoryList()
        {
            // The 'dataGridViewInventory' and 'labelNoItems' controls are
            // declared in MainForm.Designer.cs and are accessible here because of 'partial class'.

            // Bind the static list of InventoryItem objects from Program.cs to the DataGridView.
            // .ToList() creates a copy, which is generally good practice to avoid
            // issues if the underlying list changes during binding.
            dataGridViewInventory.DataSource = Program.Inventory.ToList();

            // Check if there are any items in the inventory.
            // If the inventory is empty, show the 'labelNoItems' message; otherwise, hide it.
            labelNoItems.Visible = !Program.Inventory.Any();
        }

        // Event handler for the "Add New Item" button click.
        // To link this method: in the Visual Studio designer, select 'btnAddNewItem',
        // go to Properties > Events (lightning bolt icon), and double-click the 'Click' event.
        private void btnAddNewItem_Click(object sender, EventArgs e)
        {
            // Create a new instance of the AddItemForm.
            AddItemForm addItemForm = new AddItemForm();
            // Show the AddItemForm as a dialog. This means MainForm will be
            // inactive until AddItemForm is closed.
            addItemForm.ShowDialog();

            // After AddItemForm closes (either by saving or canceling),
            // refresh the inventory list in MainForm to reflect any changes.
            RefreshInventoryList();
        }

        // Event handler for the "View/Update Selected Item" button click.
        // Your previous code had 'btnViewUpdateItem_Click_1'. This often happens if you double-click
        // a button in the designer multiple times or rename an event.
        // It's best to rename this method to 'btnViewUpdateItem_Click' for clarity,
        // and ensure it's correctly linked to the 'Click' event of 'btnViewUpdateItem' in the designer.
        private void btnViewUpdateItem_Click(object sender, EventArgs e)
        {
            // Check if any row is selected in the DataGridView.
            if (dataGridViewInventory.SelectedRows.Count > 0)
            {
                // Get the selected InventoryItem object from the DataGridView.
                // The DataBoundItem property of the selected row contains the actual object.
                InventoryItem selectedItem = (InventoryItem)dataGridViewInventory.SelectedRows[0].DataBoundItem;

                // Create an instance of the ViewUpdateItemForm, passing the selected item.
                ViewUpdateItemForm viewUpdateForm = new ViewUpdateItemForm(selectedItem);
                viewUpdateForm.ShowDialog(); // Show as a dialog.

                // After ViewUpdateItemForm closes, refresh the inventory list in MainForm.
                RefreshInventoryList();
            }
            else
            {
                // If no item is selected, display an informational message to the user.
                MessageBox.Show("Please select an item to view or update.", "No Item Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
