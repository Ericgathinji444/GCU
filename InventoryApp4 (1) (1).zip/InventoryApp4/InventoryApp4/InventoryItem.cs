﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryApp4
{
    public class InventoryItem
    {
        // Property 1: Unique identifier for the item.
        public string ItemId { get; set; }

        // Property 2: Description of the item. (Required)
        public string ItemDescription { get; set; }

        // Property 3: Quantity of the item in stock. (Required)
        public int ItemQuantity { get; set; }

        // Property 4: Cost per unit of the item. (Required)
        public decimal ItemCost { get; set; }

        // Property 5: Category of the item (e.g., Electronics, Food, Books).
        public string ItemCategory { get; set; }

        // Property 6: Date when the item was added to the inventory.
        public DateTime DateAdded { get; set; }

        // Constructor to initialize an InventoryItem object.
        public InventoryItem(string id, string description, int quantity, decimal cost, string category, DateTime dateAdded)
        {
            ItemId = id;
            ItemDescription = description;
            ItemQuantity = quantity;
            ItemCost = cost;
            ItemCategory = category;
            DateAdded = dateAdded;
        }

        // Override ToString() for easy debugging and potential display in simple lists.
        public override string ToString()
        {
            return $"{ItemDescription} (ID: {ItemId})";
        }
    }
}
